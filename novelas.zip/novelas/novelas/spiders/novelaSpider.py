import scrapy
from novelas.items import novelaScraperItem
from scrapy.loader import ItemLoader


class NovelaSpider(scrapy.Spider):
    name = 'novela'
    start_urls = ['https://www.biquge7.com/book/4652/1.html']

    def parse(self, response):
        for contents in response.css('div.content'):
            l = ItemLoader(item = novelaScraperItem(), selector=contents)
            l.add_css('titulo', 'h1.wap_none')
            l.add_css('content', 'div.Readarea.ReadAjax_content')

            yield l.load_item()

        next_page = response.css('a.Readpage_down.js_page_down').attrib['href']
        if next_page is not None:
            yield response.follow(next_page, callback=self.parse)