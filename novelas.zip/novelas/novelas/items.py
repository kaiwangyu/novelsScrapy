# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html


import scrapy
from itemloaders.processors import TakeFirst, MapCompose
from w3lib.html import remove_tags

def remove_simbols(value):
    return value.replace('<br>','').strip()

def remove_u3000(value):
    return value.replace('\u3000\u3000','').strip()

class novelaScraperItem(scrapy.Item):
    # define the fields for your item here like:
    titulo = scrapy.Field(input_processor=MapCompose(remove_tags, remove_simbols, remove_u3000))
    content = scrapy.Field(input_processor=MapCompose(remove_tags, remove_simbols, remove_u3000))


